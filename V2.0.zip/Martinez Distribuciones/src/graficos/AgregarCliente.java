package graficos;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Toolkit;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.ImageIcon;
import javax.swing.UIManager;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.border.BevelBorder;
import javax.swing.SwingConstants;
import javax.swing.border.CompoundBorder;
import javax.swing.border.MatteBorder;

import java.awt.Color;

public class AgregarCliente extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	
	String acryl="com.jtattoo.plaf.acryl.AcrylLookAndFeel";
	String hifi="com.jtattoo.plaf.hifi.HiFiLookAndFeel";
	String noire="com.jtattoo.plaf.noire.NoireLookAndFeel";
	String nimbus= "javax.swing.plaf.nimbus.NimbusLookAndFeel";
	String luna="com.jtattoo.plaf.luna.LunaLookAndFeel";
	String aero="com.jtattoo.plaf.aero.AeroLookAndFeel";
	String aluminium="com.jtattoo.plaf.aluminium.AluminiumLookAndFeel";
	String bernstein="com.jtattoo.plaf.bernstein.BernsteinLookAndFeel";
	String fast="com.jtattoo.plaf.fast.FastLookAndFeel";
	String graphite="com.jtattoo.plaf.graphite.GraphiteLookAndFeel";
	String mcwin="com.jtattoo.plaf.mcwin.McWinLookAndFeel";
	String mint="com.jtattoo.plaf.mint.MintLookAndFeel";
	String smart="com.jtattoo.plaf.smart.SmartLookAndFeel";
	String texture="com.jtattoo.plaf.texture.TextureLookAndFeel";

	/**
	 * Create the frame.
	 */
	public AgregarCliente() {
		
		setResizable(false);
		try
		
		{
		    JFrame.setDefaultLookAndFeelDecorated(true);
		    JDialog.setDefaultLookAndFeelDecorated(true);
		    UIManager.setLookAndFeel(acryl);

		}

		catch (Exception e)

		{
		    e.printStackTrace();
		}
		
		JRadioButton rdbtnFacturacion = new JRadioButton("Facturacion");
		JRadioButton rdbtnRemision = new JRadioButton("Remision");
		
		setIconImage(Toolkit.getDefaultToolkit().getImage(AgregarCliente.class.getResource("/graficos/MDCHICO.png")));
		setTitle("Clientes");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 248);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setBounds(10, 37, 306, 14);
		contentPane.add(lblNombre);
		
		textField = new JTextField();
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent arg0) {
				//crea una variable y guarda un caracter presionad
				char TeclaPresionada=arg0.getKeyChar();
				//si es enter, da click en el boton aceptar
				if(TeclaPresionada==KeyEvent.VK_ENTER){
					textField.transferFocus();
				}
			}
		});
		textField.setBounds(10, 62, 306, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				//crea una variable y guarda un caracter presionad
				char TeclaPresionada=e.getKeyChar();
				//si es enter, da click en el boton aceptar
				if(TeclaPresionada==KeyEvent.VK_ENTER){
					textField_1.transferFocus();
				}
			}
		});
		textField_1.setBounds(348, 62, 86, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblCdigo = new JLabel("C\u00F3digo");
		lblCdigo.setBounds(348, 37, 86, 14);
		contentPane.add(lblCdigo);
		
		JButton btnAgregar = new JButton("Agregar");
		btnAgregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String estado="null",linea=null;
				
				
				linea=textField_1.getText().toString()+"|"+textField.getText().toString().toUpperCase();
				
				if(rdbtnFacturacion.isSelected()&&rdbtnRemision.isSelected()){
					JOptionPane.showMessageDialog(null, "Porfavor Elija 1 sola Opcion", "Error", JOptionPane.ERROR_MESSAGE);
					rdbtnRemision.setSelected(false);
					rdbtnFacturacion.setSelected(false);
				}else{
					
					if(rdbtnFacturacion.isSelected()){
						estado="factura";
						EscribirArchivo(linea, estado);
						textField.setText("");
						textField_1.setText("");
						rdbtnFacturacion.setSelected(false);
						rdbtnRemision.setSelected(false);
					}
					if(rdbtnRemision.isSelected()){
						estado="remision";
						EscribirArchivo(linea, estado);
						textField.setText("");
						textField_1.setText("");
						rdbtnFacturacion.setSelected(false);
						rdbtnRemision.setSelected(false);
					}
					
					
				}
				
			}
		});
		btnAgregar.setBounds(345, 185, 89, 23);
		contentPane.add(btnAgregar);
		
		JButton btnBorrar = new JButton("Borrar");
		btnBorrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				textField_1.setText("");
				rdbtnFacturacion.setSelected(false);
				rdbtnRemision.setSelected(false);
			}
		});
		btnBorrar.setBounds(240, 185, 89, 23);
		contentPane.add(btnBorrar);
		
		
		rdbtnFacturacion.setBounds(196, 106, 109, 23);
		contentPane.add(rdbtnFacturacion);
		
		
		rdbtnRemision.setBounds(325, 106, 109, 23);
		contentPane.add(rdbtnRemision);
		
		JLabel lblImagen = new JLabel("");
		lblImagen.setHorizontalTextPosition(SwingConstants.CENTER);
		lblImagen.setHorizontalAlignment(SwingConstants.CENTER);
		lblImagen.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		lblImagen.setIcon(new ImageIcon(AgregarCliente.class.getResource("/graficos/person-8x.png")));
		lblImagen.setBounds(67, 93, 77, 77);
		contentPane.add(lblImagen);
	}
	
	
	
	
	
	
	
	///METODOS
	
	
	
public static void EscribirArchivo(String linea,String tipo){
		
		int Tipo=0;//0-FACTuras 1-REMISIONES 2-Producto
		String nombre="";
		File f;
	
		if(tipo.equals("factura")){
			nombre = System.getProperty("user.dir")+"\\Librerias\\Todos los Clientes Facturas.txt";
		}
		if(tipo.equals("remision")){
			nombre = System.getProperty("user.dir")+"\\Librerias\\Todos los Clientes Remisiones.txt";
		}
		if(tipo.equals("producto")){
			nombre = System.getProperty("user.dir")+"\\Librerias\\Todos los Servicios.txt";
		}
		System.out.println(nombre);
		f = new File(nombre);

		 

		//Escritura

		try{

		FileWriter w = new FileWriter(f,true);

		BufferedWriter bw = new BufferedWriter(w);
	
		
		bw.write(linea);
		bw.newLine();        //ahora cerramos los flujos de canales de datos, al cerrarlos el archivo quedar� guardado con informaci�n escrita
	
		        //de no hacerlo no se escribir� nada en el archivo
	
		JOptionPane.showMessageDialog(null, "Se ha Agregado Exitosamente");
	
		bw.close();

		}catch(IOException e){
			JOptionPane.showMessageDialog(null, "Se ha provocado un error "+e, "Error", JOptionPane.ERROR_MESSAGE);
		};
	
		 

	}
}
